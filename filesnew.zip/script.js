/* ═══════════════════════════════════════════════
   VOXLIT INTERACTION ENGINE
   1. Custom cursor
   2. Magnifying lens system
   3. Complaint fragments per section
   4. Figurine insight system
   5. Counter animations
   6. Scroll reveal
   7. Board bar animations
   8. Parallax
   9. LIVE VOTING BOARD (NEW)
═══════════════════════════════════════════════ */

/* ════════════════════════════════════════════════════════════════
   TRUE MULTI-LAYER RENDERING SYSTEM
   ════════════════════════════════════════════════════════════════

   ARCHITECTURE OVERVIEW:
   ┌─────────────────────────────────────────────────────────────┐
   │  z=501  #lens-cross   Decorative crosshair SVG              │
   │  z=500  #lens-ring-el Glow ring border (no content)         │
   │  z=10   #fg-layer     UI + semi-opaque bg + CSS mask hole   │
   │  z=1    #bg-zoom-canvas Zoomed particles (clip-path=circle) │
   │  z=0    #bg-canvas    Normal particles (always visible)      │
   └─────────────────────────────────────────────────────────────┘

   MASKING MECHANISM (how the reveal works):
   - #fg-layer has background: rgba(10,10,15,0.72)
   - CSS mask-image punches a REAL transparent hole at the lens position
   - mask: radial-gradient(circle R at LX LY, transparent 0%, transparent R-10, black R+5)
   - transparent = fg is invisible = bg canvas shows through = true reveal
   - No DOM duplication, no fake overlay, no cloned content

   ZOOM MECHANISM (how the 2x zoom works):
   - #bg-zoom-canvas renders the same particles but at scale=2.0
   - The canvas origin is shifted so the cursor maps to the zoom center:
       translateX = lx - lx*ZOOM   (= lx * (1 - ZOOM))
       translateY = ly - ly*ZOOM
   - clip-path: circle(LENS_R px at lx px ly px) restricts it to the lens circle
   - Result: inside the lens, the background appears exactly 2x zoomed, cursor-centered

   PARALLAX:
   - bg-canvas draws particles with their y position offset by scrollY * 0.2
   - bg-zoom-canvas accounts for same parallax offset inside the zoom transform
   ════════════════════════════════════════════════════════════════ */

/* ── DOM REFS ── */
const cursor    = document.getElementById('cursor');
const fgLayer   = document.getElementById('fg-layer');
const bgCanvas  = document.getElementById('bg-canvas');
// OPT-1: zoomCanvas removed — zoom is rendered mathematically in bgCanvas loop
const lensRing  = document.getElementById('lens-ring-el');
const lensCross = document.getElementById('lens-cross');
const figurine  = document.getElementById('figurine');
const figurineText = document.getElementById('figurine-text');

const bgCtx  = bgCanvas.getContext('2d');

/* ── CONSTANTS ── */
const LENS_R   = 120;   // lens radius in px
const ZOOM     = 2.0;   // zoom factor inside lens
const PARTICLE_COUNT = 55; // OPT-4: capped at 55
const SMOOTH   = 0.10;  // lens follow smoothing factor

/* ── STATE ── */
let mx = -999, my = -999;   // raw mouse position
let lx = -999, ly = -999;   // smoothed lens position
let lensVisible = false;
let lensEnabled = true;       // toggled by the LENS ON/OFF button
let mouseIdle = false;        // OPT-7: idle flag
let mouseIdleTimer = null;    // OPT-7: idle timer handle
let currentSection = 'hero';
let figurineTimer = null;
let figurineShowing = false;

/* ── ALL COMPLAINT STRINGS (flat pool, filtered by section) ── */
const ALL_COMPLAINTS = [
  "+1 pls","any update??","when is this shipping?","URGENT","we asked this last quarter",
  "still waiting...","this blocks us","hello??","we'll churn without this","critical for enterprise",
  "been requested 3x","anyone listening?","vote ++","duplicate of #847","+1 from our team too",
  "already submitted this","contradicts feature #32","urgent for Q3","+1 dark mode","also need CSV",
  "this breaks our workflow","we built a workaround","not on the roadmap?!","been 8 months",
  "high priority for us","enterprise blocker","need this yesterday","board is stale",
  "last update: 4 months ago","no one responds here","is this even monitored?","feedback goes nowhere",
  "planned since 2022","zero updates","our feedback disappeared","submitted and ignored",
  "this tool is a black hole","where did my vote go?","chaos → structure","signals clustering...",
  "duplicates merging","votes consolidating","ranking in real time","signal detected",
  "weight: 2.5x","trending ↑↑","signal: strong","votes: 247","tier: enterprise","status: planned",
  "step 1 → submit","fuzzy match: 94%","vote registered","rank updated","shipped ✓","loop closed"
];

const SECTION_COMPLAINT_POOLS = {
  hero:     ALL_COMPLAINTS.slice(0, 16),
  problem:  ALL_COMPLAINTS.slice(15, 30),
  tools:    ALL_COMPLAINTS.slice(27, 38),
  solution: ALL_COMPLAINTS.slice(38, 48),
  features: ALL_COMPLAINTS.slice(44, 52),
  how:      ALL_COMPLAINTS.slice(50, 56),
  cta:      ["ready","ranked","decided","clarity","shipped","done."]
};

const figurineInsights = {
  hero:     "We've received this request 17 times, phrased differently each time.",
  problem:  "Most votes here are from non-paying users — adjust the weight filter.",
  tools:    "This board hasn't been updated in 4 months. Users stopped submitting.",
  solution: "After weighting, the top-voted free tier feature drops to #6.",
  features: "Duplicate detection merged 23 requests into 4 core signals this week.",
  how:      "Teams that close the loop see 3x more submissions in 30 days.",
  cta:      "Your users already know what to build. They're waiting for you to listen."
};

/* ── PARTICLE SYSTEM ──
   Each particle represents a floating complaint fragment drawn directly on canvas.
   Using transforms only (x, y via ctx.translate) — no layout thrashing.
   Depth simulation via size, opacity, and blur tiers.
   OPT-4: Font string is precomputed once per particle (avoids template literals per frame).
*/
function makeParticle(pool) {
  const depthTier = Math.random(); // 0=far, 1=close
  const size = depthTier > 0.6 ? (10 + Math.random() * 4) : (7 + Math.random() * 3);
  return {
    x:    Math.random() * window.innerWidth,
    y:    Math.random() * window.innerHeight,
    vx:   (Math.random() - 0.5) * 0.35,
    vy:   (Math.random() - 0.5) * 0.20,
    oscPhase: Math.random() * Math.PI * 2,
    oscSpeed: 0.003 + Math.random() * 0.004,
    oscAmpX:  1.5 + Math.random() * 3,
    oscAmpY:  1.0 + Math.random() * 2,
    text:  pool[Math.floor(Math.random() * pool.length)],
    size,
    // OPT-4: precomputed font string — avoids template literal per frame
    font: `${Math.round(size)}px 'DM Mono', monospace`,
    opacity: depthTier > 0.6 ? (0.55 + Math.random() * 0.35) : (0.15 + Math.random() * 0.25),
    blur:  depthTier > 0.6 ? 0 : (1 + Math.random() * 2),
    // OPT-4: precomputed blur string — avoids template literal per frame
    blurStr: depthTier > 0.6 ? 'none' : `blur(${(1 + Math.random() * 2).toFixed(1)}px)`,
    angle: (Math.random() - 0.5) * 0.5,  // radians tilt
    depth: depthTier
  };
}

let particles = [];
let activePool = SECTION_COMPLAINT_POOLS.hero;

function initParticles() {
  particles = [];
  for (let i = 0; i < PARTICLE_COUNT; i++) {
    particles.push(makeParticle(activePool));
  }
}

/* ── CANVAS RESIZE ── */
// OPT-1: Only one canvas to resize now
function resizeCanvases() {
  bgCanvas.width  = window.innerWidth;
  bgCanvas.height = window.innerHeight;
}
resizeCanvases();
window.addEventListener('resize', resizeCanvases, { passive: true });

/* ── UPDATE PARTICLE POSITIONS ── */
function updateParticles(dt) {
  const W = window.innerWidth;
  const H = window.innerHeight;
  for (const p of particles) {
    p.oscPhase += p.oscSpeed * dt;
    p.x += p.vx + Math.sin(p.oscPhase) * p.oscAmpX * 0.02;
    p.y += p.vy + Math.cos(p.oscPhase * 0.7) * p.oscAmpY * 0.02;
    // Wrap around edges with padding
    if (p.x < -200) p.x = W + 100;
    if (p.x > W + 200) p.x = -100;
    if (p.y < -60) p.y = H + 30;
    if (p.y > H + 60) p.y = -30;
  }
}

/* ── DRAW ALL PARTICLES ON THE SINGLE CANVAS ──
   OPT-1: One canvas handles BOTH the normal background pass AND the zoomed
   lens pass. No second canvas needed.

   How the zoom works mathematically:
   - First pass: draw all particles normally (full viewport).
   - Second pass: clip to lens circle, apply 2× scale transform centered on
     (lx, ly), draw particles again inside that clipped region — producing the
     true zoom effect.  The clip is done via ctx.arc + ctx.clip(), so it is
     GPU-accelerated and never triggers a DOM reflow.

   OPT-4: font and blurStr are precomputed on each particle at creation time.
   OPT-5: ctx.filter (blur) is skipped on the zoom pass to avoid double cost.
*/
function drawScene(W, H, scrollY, doZoom) {
  bgCtx.clearRect(0, 0, W, H);

  // ── PASS 1: Normal background (all particles at 1× scale) ──
  bgCtx.save();
  for (const p of particles) {
    const drawY = p.y - scrollY * 0.2;

    bgCtx.save();
    bgCtx.translate(p.x, drawY);
    bgCtx.rotate(p.angle);
    bgCtx.globalAlpha = p.opacity;

    // OPT-5: only set filter when non-trivial; use precomputed string
    if (p.blur > 0.5) {
      bgCtx.filter = p.blurStr;
    } else {
      bgCtx.filter = 'none';
    }

    // OPT-4: use precomputed font string
    bgCtx.font = p.font;
    bgCtx.fillStyle = 'rgba(123,92,240,1)';
    bgCtx.textBaseline = 'middle';
    bgCtx.fillText(p.text, 0, 0);

    // Subtle glow for close particles
    if (p.depth > 0.6) {
      bgCtx.shadowColor = 'rgba(123,92,240,0.4)';
      bgCtx.shadowBlur  = 6;
      bgCtx.fillText(p.text, 0, 0);
      bgCtx.shadowBlur  = 0;
    }

    bgCtx.restore();
  }
  bgCtx.restore();

  // ── PASS 2: Zoomed lens region (clip to circle, 2× scale) ──
  // Only run when lens is visible, on-screen, and enabled
  if (!doZoom || !lensVisible || lx < -500) return;

  bgCtx.save();

  // Clip to the lens circle — no extra DOM element needed
  bgCtx.beginPath();
  bgCtx.arc(lx, ly, LENS_R, 0, Math.PI * 2);
  bgCtx.clip();

  // Apply 2× zoom centered on (lx, parallaxLy)
  const parallaxLy = ly - scrollY * 0.2;
  bgCtx.translate(lx * (1 - ZOOM), parallaxLy * (1 - ZOOM));
  bgCtx.scale(ZOOM, ZOOM);

  // Draw particles again inside the clipped/scaled region
  // OPT-5: skip blur filter on zoom pass (nearly invisible at 2× and saves GPU)
  bgCtx.filter = 'none';
  for (const p of particles) {
    const drawY = p.y - scrollY * 0.2;

    bgCtx.save();
    bgCtx.translate(p.x, drawY);
    bgCtx.rotate(p.angle);
    bgCtx.globalAlpha = p.opacity;
    bgCtx.font = p.font;
    bgCtx.fillStyle = 'rgba(123,92,240,1)';
    bgCtx.textBaseline = 'middle';
    bgCtx.fillText(p.text, 0, 0);

    if (p.depth > 0.6) {
      bgCtx.shadowColor = 'rgba(123,92,240,0.4)';
      bgCtx.shadowBlur  = 8;
      bgCtx.fillText(p.text, 0, 0);
      bgCtx.shadowBlur  = 0;
    }

    bgCtx.restore();
  }

  bgCtx.restore();
}

/* ── CURSOR ──
   OPT-6: Cursor position written directly on mousemove (no rAF needed).
   OPT-7: After 1.5 s of no movement the lens lerp is paused to save GPU.
   ZONE: Lens is suppressed when hovering over nav or interactive elements.
*/

// Elements that suppress the lens when hovered
const NAV_EL = document.querySelector('nav');
function isOverInteractive(e) {
  // Suppress over nav bar entirely
  if (NAV_EL && NAV_EL.contains(e.target)) return true;
  // Suppress over any button, link, input, select, textarea
  return !!e.target.closest('button, a, input, select, textarea, [role="button"]');
}

document.addEventListener('mousemove', e => {
  mx = e.clientX;
  my = e.clientY;
  // OPT-6: cursor DOM update happens here, not inside the rAF loop
  cursor.style.left = mx + 'px';
  cursor.style.top  = my + 'px';

  const suppressed = isOverInteractive(e);
  if (suppressed) {
    // Snap lens coordinates off-screen immediately — stops lerp trailing into nav
    lx = -999; ly = -999;
    if (lensVisible) {
      lensVisible = false;
      lensRing.style.opacity = '0';
      lensCross.style.opacity = '0';
      fgLayer.style.setProperty('--lx', '-999px');
      fgLayer.style.setProperty('--ly', '-999px');
    }
  } else if (!lensVisible && lensEnabled) {
    lensVisible = true;
    lensRing.style.opacity = '1';
    lensCross.style.opacity = '1';
  }

  // OPT-7: reset idle state on any movement
  mouseIdle = false;
  clearTimeout(mouseIdleTimer);
  mouseIdleTimer = setTimeout(() => { mouseIdle = true; }, 1500);
});

document.addEventListener('mouseleave', () => {
  lensVisible = false;
  lensRing.style.opacity = '0';
  lensCross.style.opacity = '0';
  // OPT-2: move mask hole off-screen by updating CSS vars only
  fgLayer.style.setProperty('--lx', '-999px');
  fgLayer.style.setProperty('--ly', '-999px');
  hideFigurine();
});

/* ── LENS TOGGLE ── */
function toggleLens() {
  lensEnabled = !lensEnabled;
  const btn = document.getElementById('lens-toggle');
  const lbl = document.getElementById('lens-toggle-label');
  if (lensEnabled) {
    lbl.textContent = 'LENS ON';
    btn.style.borderColor = '#2a2a2a';
    btn.style.color = '#555';
  } else {
    // Hide all lens elements immediately
    lensVisible = false;
    lensRing.style.opacity = '0';
    lensCross.style.opacity = '0';
    fgLayer.style.setProperty('--lx', '-999px');
    fgLayer.style.setProperty('--ly', '-999px');
    lbl.textContent = 'LENS OFF';
    btn.style.borderColor = 'var(--violet)';
    btn.style.color = 'var(--violet)';
  }
}

/* ── MAIN ANIMATION LOOP ──
   OPT-3: Frame throttling — physics + draw run at most every 16 ms (≈60 fps cap).
          Cursor updates are decoupled (handled directly in mousemove).
   OPT-6: Lens ring + crosshair moved via transform only; no layout reads inside loop.
   OPT-7: When mouse is idle (>1.5 s), lerp and CSS updates are skipped —
          only canvas particle animation continues at reduced frequency.
   OPT-1: Single drawScene() call replaces two separate drawParticles() calls.
   OPT-2: Mask hole updated via CSS vars — no string allocation per frame.
*/
let lastFrameTime = 0;
// OPT-7: idle frame counter — draw canvas every N frames when idle
let idleFrameCount = 0;
const IDLE_SKIP = 3; // draw 1 in every 3 frames when mouse idle (~20 fps)

function animationLoop(now) {
  requestAnimationFrame(animationLoop);

  // OPT-3: throttle to ~60 fps max
  if (now - lastFrameTime < 16) return;
  const dt = Math.min(now - lastFrameTime, 50);
  lastFrameTime = now;

  // OPT-7: When idle, skip most frames to reduce GPU load
  if (mouseIdle) {
    idleFrameCount++;
    if (idleFrameCount % IDLE_SKIP !== 0) return;
  } else {
    idleFrameCount = 0;
  }

  const W = window.innerWidth;
  const H = window.innerHeight;
  // OPT-5: fgLayer.scrollTop read once per frame (not per-particle)
  const scrollY = fgLayer ? fgLayer.scrollTop : 0;

  /* 1. Smooth lens position (lerp toward mouse)
        OPT-7: skip lerp when idle — lens is stationary so no need to update
        ZONE: skip entirely when mouse is in suppressed zone (nav / interactive) */
  const navHeight = NAV_EL ? NAV_EL.offsetHeight : 80;
  const lensZoneSuppressed = !lensVisible || !lensEnabled;

  if (!mouseIdle && !lensZoneSuppressed) {
    lx += (mx - lx) * SMOOTH;
    ly += (my - ly) * SMOOTH;
  }

  /* 2. Update particle physics */
  updateParticles(dt);

  /* 3. OPT-1: Single drawScene() renders both background AND zoomed lens pass
        on the one canvas, using ctx.clip() for the lens circle. */
  drawScene(W, H, scrollY, lensEnabled && lensVisible);

  /* 4. OPT-6: Lens ring + crosshair — transform only, no layout thrash
        OPT-7: Skip DOM writes when idle or suppressed */
  if (!mouseIdle && lensEnabled && lensVisible) {
    lensRing.style.left = lx + 'px';
    lensRing.style.top  = ly + 'px';
    lensCross.style.left = lx + 'px';
    lensCross.style.top  = ly + 'px';

    /* 5. OPT-2: Update foreground mask via CSS variables — no string rebuild */
    fgLayer.style.setProperty('--lx', lx + 'px');
    fgLayer.style.setProperty('--ly', ly + 'px');
  }
}

/* ── SECTION-BASED COMPLAINT POOL SWITCH ──
   When user scrolls to a new section, swap out the particle text pool.
   Particles gradually get new text labels as they respawn from edges.
*/
function updateComplaintPool(section) {
  activePool = SECTION_COMPLAINT_POOLS[section] || SECTION_COMPLAINT_POOLS.hero;
  // Randomly reassign text to ~30% of particles for gradual transition
  for (const p of particles) {
    if (Math.random() < 0.3) {
      p.text = activePool[Math.floor(Math.random() * activePool.length)];
    }
  }
}

// Legacy alias so sectionObserver still works
function updateLensContent(section) {
  updateComplaintPool(section);
}

function showFigurine(x, y, section) {
  if (figurineShowing) return;
  figurineShowing = true;
  figurineText.textContent = figurineInsights[section] || figurineInsights.hero;
  figurine.style.left = (x + 24) + 'px';
  figurine.style.top = (y - 80) + 'px';
  figurine.style.opacity = '1';
  clearTimeout(figurineTimer);
  figurineTimer = setTimeout(hideFigurine, 3500);
}
function hideFigurine() {
  figurine.style.opacity = '0';
  setTimeout(() => { figurineShowing = false; }, 400);
}

// Figurine random trigger removed

const sections = document.querySelectorAll('section[data-section]');
const sectionObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      const sec = entry.target.dataset.section;
      if (sec && sec !== currentSection) {
        currentSection = sec;
        updateLensContent(sec);
      }
    }
  });
}, { root: fgLayer, threshold: 0.3 });
sections.forEach(s => sectionObserver.observe(s));
updateLensContent('hero');

/* ── COUNTER ANIMATIONS ── */
function animateCounter(el) {
  const target = parseInt(el.dataset.target);
  const duration = 1800;
  const start = performance.now();
  function update(now) {
    const elapsed = now - start;
    const progress = Math.min(elapsed / duration, 1);
    const eased = 1 - Math.pow(1 - progress, 3);
    el.textContent = Math.floor(eased * target).toLocaleString();
    if (progress < 1) requestAnimationFrame(update);
    else el.textContent = target.toLocaleString();
  }
  requestAnimationFrame(update);
}
const counterObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.querySelectorAll('.cnt').forEach(animateCounter);
      counterObserver.unobserve(entry.target);
    }
  });
}, { root: fgLayer, threshold: 0.5 });
document.querySelectorAll('.hero-stats').forEach(el => counterObserver.observe(el));

/* ── SCROLL REVEAL ── */
const revealObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('visible');
      revealObserver.unobserve(entry.target);
    }
  });
}, { root: fgLayer, threshold: 0.1, rootMargin: '0px 0px -60px 0px' });
document.querySelectorAll('.reveal').forEach(el => revealObserver.observe(el));

/* ── BOARD BAR ANIMATIONS ── */
const boardObserver = new IntersectionObserver(entries => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.querySelectorAll('.b-bar-fill').forEach((bar, i) => {
        setTimeout(() => {
          bar.style.transition = `transform 0.8s cubic-bezier(0.4, 0, 0.2, 1)`;
          bar.style.transform = 'scaleX(1)';
        }, i * 120);
      });
      boardObserver.unobserve(entry.target);
    }
  });
}, { root: fgLayer, threshold: 0.4 });
const boardMock = document.getElementById('board-mock');
if (boardMock) boardObserver.observe(boardMock);

document.getElementById('hero').dataset.section = 'hero';
sectionObserver.observe(document.getElementById('hero'));

/* ── INITIALIZE CANVAS SYSTEM & START LOOP ── */
initParticles();
// OPT-3: rAF call is at the TOP of animationLoop now (prevents stacking on slow frames)
requestAnimationFrame(animationLoop);

/* ── SCROLL HELPER ──
   Since fg-layer is our scrolling container (position:fixed, overflow-y:auto),
   window.scrollY is always 0. Use this helper everywhere instead of scrollIntoView.
*/
function scrollToEl(el) {
  if (!el || !fgLayer) return;
  const elRect = el.getBoundingClientRect();
  const fgRect = fgLayer.getBoundingClientRect();
  fgLayer.scrollBy({ top: elRect.top - fgRect.top - 80, behavior: 'smooth' });
}
// Patch all inline scrollIntoView references
window.__scrollTo = scrollToEl;

// No separate scroll tracking needed — animationLoop reads fgLayer.scrollTop directly each frame
fgLayer.addEventListener('scroll', () => {}, { passive: true });


/* ══════════════════════════════════════════════════════════════
   LIVE VOTING BOARD ENGINE
══════════════════════════════════════════════════════════════ */

const LS_VOTES    = 'fv_votes';
const LS_FEATURES = 'fv_features';
const LS_COMMENTS = 'fv_comments';
const LS_MATRIX   = 'fv_matrix';
const LS_POWER    = 'fv_power';

/* ── DEFAULT FEATURES ── */
const DEFAULT_FEATURES = [
  { id:'f1', title:'Dark mode support', desc:'A full dark theme for the entire interface. Eyes bleed at night without it.', status:'Planned', createdAt: Date.now()-7*86400000, submitter:'Team Voxlit' },
  { id:'f2', title:'CSV / Excel export', desc:'Export the full feature list with vote counts to a spreadsheet for offline analysis.', status:'Under Review', createdAt: Date.now()-5*86400000, submitter:'Priya M.' },
  { id:'f3', title:'API webhooks on status change', desc:'Fire a webhook when a feature moves to In Progress or Shipped so we can auto-update our Jira.', status:'Under Review', createdAt: Date.now()-4*86400000, submitter:'Karan D.' },
  { id:'f4', title:'Slack integration', desc:'Post a message to a Slack channel whenever a feature is shipped or a new top-voted request appears.', status:'Shipped', createdAt: Date.now()-10*86400000, submitter:'Dev Team' },
  { id:'f5', title:'Mobile app (iOS & Android)', desc:'A native mobile app so users can vote and submit requests on the go, not just on desktop.', status:'Planned', createdAt: Date.now()-3*86400000, submitter:'Ananya S.' },
];
const DEFAULT_VOTES = { f1:247, f2:189, f3:142, f4:98, f5:74 };

function loadFeatures() {
  try {
    const raw = localStorage.getItem(LS_FEATURES);
    return raw ? JSON.parse(raw) : DEFAULT_FEATURES.map(f=>({...f}));
  } catch(e) { return DEFAULT_FEATURES.map(f=>({...f})); }
}
function saveFeatures(arr) { localStorage.setItem(LS_FEATURES, JSON.stringify(arr)); }

function loadVotes() {
  try {
    const raw = localStorage.getItem(LS_VOTES);
    if (!raw) return { counts:{...DEFAULT_VOTES}, mine:[] };
    const d = JSON.parse(raw);
    // fill defaults for any missing
    DEFAULT_FEATURES.forEach(f => { if(d.counts[f.id]===undefined) d.counts[f.id]=DEFAULT_VOTES[f.id]; });
    return d;
  } catch(e) { return { counts:{...DEFAULT_VOTES}, mine:[] }; }
}
function saveVotes(v) { localStorage.setItem(LS_VOTES, JSON.stringify(v)); }

function loadComments() {
  try { return JSON.parse(localStorage.getItem(LS_COMMENTS)||'{}'); }
  catch(e) { return {}; }
}
function saveComments(c) { localStorage.setItem(LS_COMMENTS, JSON.stringify(c)); }

function loadMatrix() {
  try { return JSON.parse(localStorage.getItem(LS_MATRIX)||'{}'); }
  catch(e) { return {}; }
}
function saveMatrix(m) { localStorage.setItem(LS_MATRIX, JSON.stringify(m)); }

function loadPowerUsers() {
  try { return JSON.parse(localStorage.getItem(LS_POWER)||'[]'); }
  catch(e) { return []; }
}
function savePowerUsers(arr) { localStorage.setItem(LS_POWER, JSON.stringify(arr)); }

/* ── STATE ── */
let features = loadFeatures();
let voteData  = loadVotes();
let comments  = loadComments();
let matrixMap = loadMatrix();
let powerUsers = loadPowerUsers();
let openComments = new Set();
let expandedDescs = new Set();
let filterStatus = 'all';
let sortBy = 'votes';
let searchQuery = '';
let adminOpen = false;
let trendWindow = {};

// Compute trending (votes in last 7 days — we fake it with stored data)
function trendScore(fid) {
  return (voteData.counts[fid] || 0) * 0.6 + Math.random() * 10;
}

function getEffectiveVotes(fid) {
  const base = voteData.counts[fid] || 0;
  // power user bonus: stored in voteData
  return base;
}

function statusClass(s) {
  if (s==='Planned') return 'planned';
  if (s==='In Progress') return 'progress';
  if (s==='Shipped') return 'shipped';
  return 'review';
}

function timeAgo(ts) {
  const diff = Date.now() - ts;
  const days = Math.floor(diff / 86400000);
  if (days < 1) return 'today';
  if (days === 1) return '1 day ago';
  if (days < 30) return `${days} days ago`;
  const months = Math.floor(days / 30);
  return `${months}mo ago`;
}

function getSorted() {
  let list = [...features];
  if (filterStatus !== 'all') list = list.filter(f => f.status === filterStatus);
  if (searchQuery) {
    const q = searchQuery.toLowerCase();
    list = list.filter(f => f.title.toLowerCase().includes(q) || f.desc.toLowerCase().includes(q));
  }
  if (sortBy === 'votes') list.sort((a,b) => (voteData.counts[b.id]||0) - (voteData.counts[a.id]||0));
  else if (sortBy === 'newest') list.sort((a,b) => b.createdAt - a.createdAt);
  else if (sortBy === 'trending') list.sort((a,b) => trendScore(b.id) - trendScore(a.id));
  return list;
}

/* ── RENDER ── */
function renderBoard() {
  const list = getSorted();
  const container = document.getElementById('feature-list');

  if (list.length === 0) {
    container.innerHTML = `<div class="empty-state"><div class="empty-state-icon">📭</div><div class="empty-state-text">NO FEATURES MATCH THIS FILTER</div></div>`;
    return;
  }

  // Build new HTML
  const html = list.map((f, idx) => {
    const rank = idx + 1;
    const votes = voteData.counts[f.id] || 0;
    const voted = voteData.mine.includes(f.id);
    const sc = statusClass(f.status);
    const commArr = comments[f.id] || [];
    const isOpen = openComments.has(f.id);
    const isExpanded = expandedDescs.has(f.id);
    const isPower = powerUsers.includes(f.id); // note: power user toggle is per-feature for demo

    return `<div class="feature-card${rank===1?' rank-1':''}" id="card-${f.id}" data-id="${f.id}" draggable="true" ondragstart="onDragStart(event,'${f.id}')">
      <div class="card-inner">
        <div class="card-vote-col">
          <button class="vote-btn${voted?' voted':''}" id="vbtn-${f.id}" onclick="castVote('${f.id}')" title="${voted?'Remove vote':'I need this too'}">
            <svg width="14" height="14" viewBox="0 0 14 14" fill="none"><path d="M7 11V3M3 7l4-4 4 4" stroke="${voted?'#fff':'#555'}" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>
          </button>
          <div class="vote-count-wrap"><span class="vote-count" id="vc-${f.id}">${votes}</span></div>
          <div class="vote-label">VOTES</div>
          ${isPower ? `<div class="vote-power-note">⚡ 2×</div>` : ''}
        </div>
        <div class="card-body">
          <div style="display:flex;align-items:center;gap:10px;margin-bottom:4px;">
            <div class="card-rank">#${rank}</div>
            <div class="card-title">${escHtml(f.title)}</div>
          </div>
          <div class="card-desc${isExpanded?' expanded':''}" id="desc-${f.id}">${escHtml(f.desc)}</div>
          <button class="card-read-more" onclick="toggleDesc('${f.id}')">${isExpanded?'COLLAPSE ↑':'READ MORE ↓'}</button>
          <div class="card-meta">
            <span class="status-tag ${sc}">${f.status.toUpperCase()}</span>
            <span class="card-timestamp">${timeAgo(f.createdAt)}</span>
            ${f.submitter ? `<span class="card-submitter">by ${escHtml(f.submitter)}</span>` : ''}
            ${commArr.length>0 ? `<span class="card-submitter">${commArr.length} comment${commArr.length>1?'s':''}</span>` : ''}
          </div>
        </div>
      </div>
      <div class="card-footer-row">
        <button class="card-action-btn${isOpen?' active':''}" onclick="toggleComments('${f.id}')">
          💬 ${isOpen?'HIDE':'COMMENTS'} (${commArr.length})
        </button>
        <button class="card-action-btn" onclick="castVote('${f.id}')">
          ${voted ? '✓ VOTED' : '▲ I NEED THIS TOO'}
        </button>
      </div>
      <div class="card-comments${isOpen?' open':''}" id="cmts-${f.id}">
        <div class="comments-inner">
          ${commArr.length===0 ? '<div style="font-family:\'DM Mono\',monospace;font-size:10px;color:#2a2a2a;letter-spacing:1px;padding:8px 0;">NO COMMENTS YET</div>' :
            commArr.map(c=>`<div class="comment-item"><div class="comment-author">${escHtml(c.author||'ANONYMOUS')} · ${timeAgo(c.ts)}</div>${escHtml(c.text)}</div>`).join('')
          }
          <div class="comment-input-row">
            <input type="text" class="form-input comment-input" id="cmtin-${f.id}" placeholder="Add a comment..." style="font-size:12px;" onkeydown="if(event.key==='Enter')postComment('${f.id}')"/>
            <button class="comment-submit" onclick="postComment('${f.id}')">POST</button>
          </div>
        </div>
      </div>
    </div>`;
  }).join('');

  container.innerHTML = html;
  updateStats();
  renderKanban();
  renderMatrix();
}

function escHtml(str) {
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function updateStats() {
  const total = Object.values(voteData.counts).reduce((s,v)=>s+v,0);
  const myCount = voteData.mine.length;
  document.getElementById('stat-total-votes').textContent = total;
  document.getElementById('stat-feature-count').textContent = features.length;
  document.getElementById('stat-my-votes').textContent = myCount;
}

/* ── VOTING ── */
function castVote(fid) {
  const btn = document.getElementById('vbtn-'+fid);
  const vc  = document.getElementById('vc-'+fid);
  const voted = voteData.mine.includes(fid);

  if (voted) {
    // unvote
    voteData.mine = voteData.mine.filter(id => id !== fid);
    voteData.counts[fid] = Math.max(0, (voteData.counts[fid]||0) - 1);
  } else {
    voteData.mine.push(fid);
    voteData.counts[fid] = (voteData.counts[fid]||0) + 1;
    btn.classList.add('clicked');
    setTimeout(()=>btn.classList.remove('clicked'), 350);
    // Check milestone
    const newCount = voteData.counts[fid];
    if (newCount % 10 === 0 && newCount > 0) {
      const f = features.find(x=>x.id===fid);
      if (f) {
        showToast('MILESTONE 🎉', `"${f.title}" just hit ${newCount} votes!`);
        spawnConfetti(btn);
      }
    }
  }

  saveVotes(voteData);

  // Animate count
  if (vc) {
    vc.classList.remove('count-animating');
    void vc.offsetWidth;
    vc.textContent = voteData.counts[fid];
    vc.classList.add('count-animating');
    setTimeout(()=>vc.classList.remove('count-animating'), 400);
  }

  // Re-render with animation
  setTimeout(() => {
    renderBoard();
  }, 180);

  updateStats();
}

/* ── COMMENTS ── */
function toggleComments(fid) {
  if (openComments.has(fid)) openComments.delete(fid);
  else openComments.add(fid);
  renderBoard();
}

function postComment(fid) {
  const input = document.getElementById('cmtin-'+fid);
  if (!input) return;
  const text = input.value.trim();
  if (!text) return;
  if (!comments[fid]) comments[fid] = [];
  comments[fid].push({ text, author: 'You', ts: Date.now() });
  saveComments(comments);
  showToast('COMMENT POSTED', 'Your comment was added.');
  renderBoard();
  setTimeout(()=>{ openComments.add(fid); renderBoard(); }, 10);
}

function toggleDesc(fid) {
  if (expandedDescs.has(fid)) expandedDescs.delete(fid);
  else expandedDescs.add(fid);
  renderBoard();
}

/* ── SUBMIT FEATURE ── */
function onTitleInput() {
  const val = document.getElementById('f-title').value;
  const counter = document.getElementById('title-counter');
  counter.textContent = `${val.length}/60`;
  counter.className = 'char-counter' + (val.length>50?' warn':'') + (val.length>58?' danger':'');
  checkDuplicates(val);
}

function onDescInput() {
  const val = document.getElementById('f-desc').value;
  const counter = document.getElementById('desc-counter');
  counter.textContent = `${val.length}/280`;
  counter.className = 'char-counter' + (val.length>240?' warn':'') + (val.length>270?' danger':'');
}

function checkDuplicates(title) {
  const dw = document.getElementById('dupe-warning');
  const ds = document.getElementById('dupe-suggestions');
  if (title.length < 4) { dw.style.display='none'; return; }
  const q = title.toLowerCase().trim();
  const matches = features.filter(f => {
    const ft = f.title.toLowerCase();
    return ft.includes(q) || q.includes(ft.substring(0,6)) ||
      levenshtein(q, ft) < Math.max(4, Math.floor(ft.length*0.4));
  }).slice(0,3);
  if (matches.length > 0) {
    dw.style.display='block';
    ds.innerHTML = matches.map(m => `
      <div class="dupe-item">
        <div>
          <div class="dupe-title">${escHtml(m.title)}</div>
          <div class="dupe-votes">${voteData.counts[m.id]||0} votes · ${m.status}</div>
        </div>
        <button class="dupe-vote-instead" onclick="castVote('${m.id}');document.getElementById('f-title').value='';document.getElementById('dupe-warning').style.display='none';showToast('VOTED','Your vote was cast on the existing request.');">VOTE INSTEAD</button>
      </div>`).join('');
  } else {
    dw.style.display='none';
  }
}

function levenshtein(a, b) {
  const m=a.length, n=b.length;
  const dp=Array.from({length:m+1},(_,i)=>[i,...Array(n).fill(0)]);
  for(let j=0;j<=n;j++) dp[0][j]=j;
  for(let i=1;i<=m;i++) for(let j=1;j<=n;j++) {
    dp[i][j]=a[i-1]===b[j-1]?dp[i-1][j-1]:1+Math.min(dp[i-1][j],dp[i][j-1],dp[i-1][j-1]);
  }
  return dp[m][n];
}

function submitFeature() {
  const title = document.getElementById('f-title').value.trim();
  const desc  = document.getElementById('f-desc').value.trim();
  const name  = document.getElementById('f-name').value.trim();
  const errEl = document.getElementById('form-error');

  if (!title) { showFormError('Title is required.'); return; }
  if (title.length < 5) { showFormError('Title must be at least 5 characters.'); return; }
  if (!desc)  { showFormError('Description is required.'); return; }

  // Exact duplicate check
  const exact = features.find(f => f.title.toLowerCase() === title.toLowerCase());
  if (exact) { showFormError('A feature with this exact title already exists. Vote for it instead!'); return; }

  errEl.style.display='none';
  document.getElementById('submit-btn').style.display='none';
  document.getElementById('submit-loader').style.display='flex';

  setTimeout(() => {
    const newId = 'f' + Date.now();
    const newFeature = {
      id: newId, title, desc,
      status: 'Under Review',
      createdAt: Date.now(),
      submitter: name || null
    };
    features.push(newFeature);
    voteData.counts[newId] = 0;
    saveFeatures(features);
    saveVotes(voteData);

    document.getElementById('f-title').value='';
    document.getElementById('f-desc').value='';
    document.getElementById('f-name').value='';
    document.getElementById('title-counter').textContent='0/60';
    document.getElementById('desc-counter').textContent='0/280';
    document.getElementById('dupe-warning').style.display='none';
    document.getElementById('submit-btn').style.display='';
    document.getElementById('submit-loader').style.display='none';

    // Add entering animation
    renderBoard();
    setTimeout(()=>{
      const card = document.getElementById('card-'+newId);
      if (card) card.classList.add('card-entering');
    }, 50);

    showToast('SUBMITTED ✓', `"${title}" is now Under Review.`);
    updateStats();
  }, 800);
}

function showFormError(msg) {
  const el = document.getElementById('form-error');
  el.textContent = msg;
  el.style.display='block';
}

/* ── FILTER / SORT ── */
document.getElementById('filter-status').addEventListener('change', e => {
  filterStatus = e.target.value;
  renderBoard();
});
document.getElementById('sort-by').addEventListener('change', e => {
  sortBy = e.target.value;
  renderBoard();
});
document.getElementById('search-input').addEventListener('input', e => {
  searchQuery = e.target.value.trim();
  renderBoard();
});

/* ── KEYBOARD SHORTCUT ── */
document.addEventListener('keydown', e => {
  if (e.key === 'n' || e.key === 'N') {
    if (document.activeElement.tagName === 'INPUT' || document.activeElement.tagName === 'TEXTAREA') return;
    const board = document.getElementById('live-board');
    window.__scrollTo(board);
    setTimeout(()=>document.getElementById('f-title').focus(), 600);
  }
});

/* ── ADMIN PANEL ── */
function toggleAdmin() {
  adminOpen = !adminOpen;
  const panel = document.getElementById('admin-panel');
  panel.style.display = adminOpen ? 'block' : 'none';
  if (adminOpen) renderAdminPanel();
}

function renderAdminPanel() {
  const list = document.getElementById('admin-feature-list');
  list.innerHTML = features.map(f => `
    <div class="admin-card">
      <div class="admin-card-title">${escHtml(f.title)}</div>
      <div class="admin-card-votes">${voteData.counts[f.id]||0} votes · ${timeAgo(f.createdAt)}</div>
      <select class="admin-status-select" onchange="changeStatus('${f.id}',this.value)">
        ${['Under Review','Planned','In Progress','Shipped'].map(s=>`<option value="${s}"${f.status===s?' selected':''}>${s.toUpperCase()}</option>`).join('')}
      </select>
      <div class="admin-power-toggle" onclick="togglePowerUser('${f.id}')">
        <div class="toggle-switch${powerUsers.includes(f.id)?' on':''}" id="pw-${f.id}"></div>
        MARK AS POWER-USER VOTE (2×)
      </div>
    </div>`).join('');
  updateWeightLabel();
}

function changeStatus(fid, newStatus) {
  const f = features.find(x=>x.id===fid);
  if (!f) return;
  const oldStatus = f.status;
  f.status = newStatus;
  saveFeatures(features);
  if (newStatus === 'Shipped' && voteData.mine.includes(fid)) {
    showToast('SHIPPED! 🚀', `"${f.title}" has shipped — you voted for this!`);
    const card = document.getElementById('card-'+fid);
    if (card) spawnConfetti(card);
  } else {
    showToast('STATUS UPDATED', `"${f.title}" → ${newStatus}`);
  }
  renderBoard();
  renderAdminPanel();
}

function togglePowerUser(fid) {
  if (powerUsers.includes(fid)) {
    powerUsers = powerUsers.filter(id=>id!==fid);
  } else {
    powerUsers.push(fid);
    // Add 2x vote weight (add another vote count)
    voteData.counts[fid] = (voteData.counts[fid]||0) + Math.floor((voteData.counts[fid]||0) * 0.1);
    saveVotes(voteData);
  }
  savePowerUsers(powerUsers);
  const sw = document.getElementById('pw-'+fid);
  if (sw) sw.classList.toggle('on', powerUsers.includes(fid));
  updateWeightLabel();
  renderBoard();
}

function updateWeightLabel() {
  const el = document.getElementById('weight-info');
  if (el) el.textContent = `Power users: ${powerUsers.length} marked`;
}

/* ── EFFORT/IMPACT MATRIX ── */
function renderMatrix() {
  ['q1','q2','q3','q4'].forEach(q => {
    const drop = document.querySelector(`.q-drop[data-q="${q}"]`);
    if (!drop) return;
    const featureIds = Object.entries(matrixMap).filter(([,v])=>v===q).map(([k])=>k);
    drop.innerHTML = featureIds.map(fid => {
      const f = features.find(x=>x.id===fid);
      if (!f) return '';
      return `<div class="matrix-chip" draggable="true" ondragstart="onDragStart(event,'${fid}')" title="${escHtml(f.title)}">${escHtml(f.title.substring(0,20))}${f.title.length>20?'…':''}</div>`;
    }).join('');
  });
  setupMatrixDrop();
}

function setupMatrixDrop() {
  document.querySelectorAll('.matrix-quadrant').forEach(q => {
    q.ondragover = e => { e.preventDefault(); q.classList.add('drag-over'); };
    q.ondragleave = () => q.classList.remove('drag-over');
    q.ondrop = e => {
      e.preventDefault();
      q.classList.remove('drag-over');
      const fid = e.dataTransfer.getData('featureId');
      if (fid) {
        const qKey = q.querySelector('.q-drop').dataset.q;
        matrixMap[fid] = qKey;
        saveMatrix(matrixMap);
        renderMatrix();
        showToast('MATRIX UPDATED', 'Feature placed on the effort/impact matrix.');
      }
    };
  });
}

function onDragStart(e, fid) {
  e.dataTransfer.setData('featureId', fid);
  e.dataTransfer.effectAllowed = 'move';
}

/* ── KANBAN ── */
function renderKanban() {
  const cols = { 'Planned':'kc-planned', 'In Progress':'kc-inprogress', 'Shipped':'kc-shipped' };
  Object.entries(cols).forEach(([status, colId]) => {
    const col = document.getElementById(colId);
    if (!col) return;
    const items = features.filter(f=>f.status===status);
    if (items.length === 0) {
      col.innerHTML = '<div style="font-family:\'DM Mono\',monospace;font-size:9px;color:#1a1a1a;letter-spacing:1px;padding:8px 0;">EMPTY</div>';
    } else {
      col.innerHTML = items.map(f=>`
        <div class="kanban-chip">
          ${escHtml(f.title)}
          <div class="kanban-chip-votes">${voteData.counts[f.id]||0} votes</div>
        </div>`).join('');
    }
  });
}

/* ── TOAST ── */
function showToast(type, msg) {
  const container = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = 'toast';
  el.innerHTML = `<div class="toast-type">${type}</div>${escHtml(msg)}`;
  container.appendChild(el);
  setTimeout(() => {
    el.classList.add('toast-out');
    setTimeout(()=>el.remove(), 400);
  }, 3500);
}

/* ── CONFETTI ── */
function spawnConfetti(anchorEl) {
  const colors = ['#7B5CF0','#a080ff','#ffffff','#3a7a3a','#ff9900'];
  const rect = anchorEl ? anchorEl.getBoundingClientRect() : {left:window.innerWidth/2,top:window.innerHeight/2};
  for (let i=0;i<24;i++) {
    const p = document.createElement('div');
    p.className = 'confetti-piece';
    p.style.cssText = `
      left:${rect.left+rect.width/2}px;top:${rect.top}px;
      background:${colors[Math.floor(Math.random()*colors.length)]};
      animation-duration:${0.8+Math.random()*0.8}s;
      animation-delay:${Math.random()*0.3}s;
      transform:translateX(${-60+Math.random()*120}px);
      width:${4+Math.random()*6}px;height:${4+Math.random()*6}px;
    `;
    document.body.appendChild(p);
    setTimeout(()=>p.remove(), 1500);
  }
}

/* ── INIT ── */
document.addEventListener('DOMContentLoaded', () => {
  renderBoard();
  // Stagger card entrance
  setTimeout(() => {
    document.querySelectorAll('.feature-card').forEach((card, i) => {
      card.style.opacity = '0';
      card.style.transform = 'translateY(20px)';
      setTimeout(() => {
        card.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
        card.style.opacity = '1';
        card.style.transform = 'translateY(0)';
      }, i * 80);
    });
  }, 100);
});
const PAGES = {
product: () => `<div class="pp-hero"><div class="pp-eyebrow">WHAT IS VOXLIT</div><h1 class="pp-h1">The only board that turns<br/>noise into <em>decisions.</em></h1><p class="pp-lead">Most feedback tools collect requests and stop there. Voxlit closes the loop — from raw user chaos to a ranked, weighted, actionable roadmap your whole team can rally around.</p></div><div class="pp-grid"><div class="pp-cell"><div class="pp-cell-num">01 ——</div><div class="pp-cell-title">Built for product teams</div><div class="pp-cell-desc">Voxlit was designed by PMs who got burned by spreadsheets, stale Canny boards, and HiPPO-driven roadmaps. Every feature exists because someone needed it badly.</div><div class="pp-cell-tag">PM-FIRST DESIGN</div></div><div class="pp-cell"><div class="pp-cell-num">02 ——</div><div class="pp-cell-title">Not another feedback box</div><div class="pp-cell-desc">We don't just collect. We deduplicate, weight, rank, and notify. The board you see is a living prioritization engine, not a graveyard of ignored requests.</div><div class="pp-cell-tag">ACTIVE INTELLIGENCE</div></div><div class="pp-cell"><div class="pp-cell-num">03 ——</div><div class="pp-cell-title">Transparent to users</div><div class="pp-cell-desc">Users can see exactly where their request sits, how many others voted, and what status it's in. Radical transparency kills churn from "my feedback went nowhere."</div><div class="pp-cell-tag">OPEN BY DEFAULT</div></div><div class="pp-cell"><div class="pp-cell-num">04 ——</div><div class="pp-cell-title">Ops-ready from day one</div><div class="pp-cell-desc">Admin panel, status transitions, voter notifications, and an effort/impact matrix ship out of the box. No expensive enterprise plan required.</div><div class="pp-cell-tag">NO GATEKEEPING</div></div></div><div class="pp-full"><div class="pp-section-label"><em>IMPACT</em> — BY THE NUMBERS</div><div class="pp-stats"><div class="pp-stat"><div class="pp-stat-num">3×</div><div class="pp-stat-label">MORE SUBMISSIONS WHEN LOOP CLOSES</div></div><div class="pp-stat"><div class="pp-stat-num">68%</div><div class="pp-stat-label">REDUCTION IN DUPLICATE REQUESTS</div></div><div class="pp-stat"><div class="pp-stat-num">14d</div><div class="pp-stat-label">AVG TIME TO FIRST SHIPPING DECISION</div></div></div></div><div class="pp-full"><div class="pp-section-label"><em>VOXLIT VS</em> — THE OLD WAY</div><div class="pp-compare"><div class="pp-compare-col"><div class="pp-compare-title" style="color:#5a2020;">✗ WITHOUT VOXLIT</div><div class="pp-compare-item"><span class="icon">✗</span>CEO overrides 200 user votes with gut feeling</div><div class="pp-compare-item"><span class="icon">✗</span>Same feature submitted 12 ways, votes split</div><div class="pp-compare-item"><span class="icon">✗</span>Users submit once, never hear back, stop engaging</div><div class="pp-compare-item"><span class="icon">✗</span>Free tier users drown out paying customers</div><div class="pp-compare-item"><span class="icon">✗</span>Roadmap is a political document, not a product strategy</div></div><div class="pp-compare-col"><div class="pp-compare-title" style="color:#2a6a2a;">✓ WITH VOXLIT</div><div class="pp-compare-item"><span class="icon">✓</span>Data-backed ranking your exec team can't easily dismiss</div><div class="pp-compare-item"><span class="icon">✓</span>Fuzzy dedup merges variants before votes fragment</div><div class="pp-compare-item"><span class="icon">✓</span>Voters notified on status changes — loop closed</div><div class="pp-compare-item"><span class="icon">✓</span>Role-weighted votes surface paying customer signal</div><div class="pp-compare-item"><span class="icon">✓</span>Effort/Impact matrix turns votes into sprint decisions</div></div></div></div><div class="pp-full"><div class="pp-section-label"><em>PRICING</em></div><div class="pp-pricing"><div class="pp-plan"><div class="pp-plan-name">STARTER</div><div class="pp-plan-price">$0<span> / mo</span></div><div class="pp-plan-features"><div class="pp-plan-feat">Unlimited feature requests</div><div class="pp-plan-feat">Real-time ranked voting</div><div class="pp-plan-feat">localStorage persistence</div><div class="pp-plan-feat">Basic status lifecycle</div><div class="pp-plan-feat">Up to 3 team members</div></div></div><div class="pp-plan highlight"><div class="pp-plan-badge">MOST POPULAR</div><div class="pp-plan-name">GROWTH</div><div class="pp-plan-price">$49<span> / mo</span></div><div class="pp-plan-features"><div class="pp-plan-feat">Everything in Starter</div><div class="pp-plan-feat">Duplicate detection + fuzzy merge</div><div class="pp-plan-feat">Voter email notifications</div><div class="pp-plan-feat">Effort / Impact matrix</div><div class="pp-plan-feat">Admin dashboard</div><div class="pp-plan-feat">Up to 15 team members</div></div></div><div class="pp-plan"><div class="pp-plan-name">ENTERPRISE</div><div class="pp-plan-price">$199<span> / mo</span></div><div class="pp-plan-features"><div class="pp-plan-feat">Everything in Growth</div><div class="pp-plan-feat">Vote weighting by user tier</div><div class="pp-plan-feat">SSO + SAML</div><div class="pp-plan-feat">API + webhook access</div><div class="pp-plan-feat">SLA + dedicated support</div><div class="pp-plan-feat">Unlimited members</div></div></div></div></div><div class="pp-cta-strip"><h2 class="pp-h2">Ready to replace<br/><em>instinct with signal?</em></h2><p>Your users are already telling you what to build. Voxlit makes sure you're actually listening.</p><button class="pp-cta-btn" onclick="closePage();window.__scrollTo(document.getElementById('live-board'))">Try the live board →</button></div>`,

features: () => `<div class="pp-hero"><div class="pp-eyebrow">FEATURE DEEP DIVE</div><h1 class="pp-h1">Every feature earns<br/>its place by <em>doing work.</em></h1><p class="pp-lead">No bloat. No settings menus that take 20 minutes to figure out. Every capability in Voxlit was added because a real PM needed it to make a real decision faster.</p></div><div class="pp-full" style="padding-bottom:0;"><div class="pp-section-label"><em>CORE</em> — THE FOUNDATION</div></div><div class="pp-feat-list"><div class="pp-feat-item"><div class="pp-feat-icon"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 12V4M4 8l4-4 4 4" stroke="#7B5CF0" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg></div><div><div class="pp-feat-name">Real-time ranked voting</div><div class="pp-feat-desc">Every upvote triggers an instant re-sort with a smooth reorder animation. The board always reflects live user priority. Vote counts animate as they change so movement feels alive, not mechanical.</div><div class="pp-feat-new">LIVE IN BOARD</div></div></div><div class="pp-feat-item"><div class="pp-feat-icon"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="2" y="2" width="12" height="12" rx="1" stroke="#7B5CF0" stroke-width="1.3"/><path d="M5 8h6M5 5h4M5 11h3" stroke="#7B5CF0" stroke-width="1.3" stroke-linecap="round"/></svg></div><div><div class="pp-feat-name">Status lifecycle</div><div class="pp-feat-desc">Under Review → Planned → In Progress → Shipped. Each status has distinct color coding. The public roadmap Kanban updates in sync. Admin transitions status in one click from the admin panel.</div><div class="pp-feat-new">4 STATUSES</div></div></div><div class="pp-feat-item"><div class="pp-feat-icon"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><circle cx="6" cy="6" r="4" stroke="#7B5CF0" stroke-width="1.3"/><path d="M9.5 9.5L13 13" stroke="#7B5CF0" stroke-width="1.3" stroke-linecap="round"/></svg></div><div><div class="pp-feat-name">localStorage persistence</div><div class="pp-feat-desc">All votes, submitted features, comments, and matrix placements survive hard refresh. Namespaced keys (fv_votes, fv_features, fv_comments, fv_matrix) prevent collisions with other scripts.</div><div class="pp-feat-new">ZERO BACKEND</div></div></div></div><div class="pp-full" style="padding-bottom:0;padding-top:40px;"><div class="pp-section-label"><em>DIFFERENTIATION</em> — WHAT MAKES IT NOT GENERIC</div></div><div class="pp-feat-list"><div class="pp-feat-item"><div class="pp-feat-icon"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 8c0-2.8 2.2-5 5-5s5 2.2 5 5-2.2 5-5 5" stroke="#7B5CF0" stroke-width="1.3" stroke-linecap="round"/><path d="M5 12l-2 2M5 12l-2-1" stroke="#7B5CF0" stroke-width="1.3" stroke-linecap="round"/></svg></div><div><div class="pp-feat-name">Fuzzy duplicate detection</div><div class="pp-feat-desc">Levenshtein distance matching checks new titles against existing requests in real time. "Did you mean X?" UI appears with a one-click "Vote instead" button. Prevents vote fragmentation — the single biggest signal-killer on voting boards.</div><div class="pp-feat-new">FIRES ON KEYSTROKE</div></div></div><div class="pp-feat-item"><div class="pp-feat-icon"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M8 2v4M8 10v4M2 8h4M10 8h4" stroke="#7B5CF0" stroke-width="1.3" stroke-linecap="round"/><circle cx="8" cy="8" r="2" stroke="#7B5CF0" stroke-width="1.3"/></svg></div><div><div class="pp-feat-name">Vote weight by role (2× power users)</div><div class="pp-feat-desc">The admin panel lets you mark features as power-user requests. Their votes carry a configurable 1.5×, 2×, or 3× multiplier, displayed transparently on the card. Prevents free-tier popularity contests from burying enterprise priorities.</div><div class="pp-feat-new">CONFIGURABLE MULTIPLIER</div></div></div><div class="pp-feat-item"><div class="pp-feat-icon"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><rect x="2" y="9" width="5" height="5" stroke="#7B5CF0" stroke-width="1.3"/><rect x="9" y="2" width="5" height="5" stroke="#7B5CF0" stroke-width="1.3"/><rect x="9" y="9" width="5" height="5" stroke="#7B5CF0" stroke-width="1.3" opacity="0.4"/></svg></div><div><div class="pp-feat-name">Effort / Impact matrix</div><div class="pp-feat-desc">Drag-and-drop 2×2 quadrant — Ship It, Plan It, Fill Time, Park It. Drag any feature card from the list into a quadrant. Placements persist in localStorage. Turns a popularity contest into a prioritization tool.</div><div class="pp-feat-new">DRAG FROM ANY CARD</div></div></div><div class="pp-feat-item"><div class="pp-feat-icon"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M2 12l4-4 3 3 5-7" stroke="#7B5CF0" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg></div><div><div class="pp-feat-name">Trending sort (vote velocity)</div><div class="pp-feat-desc">Beyond "most voted," Trending surfaces features gaining momentum right now — not legacy popularity. Catches fast-rising requests before they become noise. Available alongside Top Voted and Newest in the sort dropdown.</div><div class="pp-feat-new">3 SORT MODES</div></div></div><div class="pp-feat-item"><div class="pp-feat-icon"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M3 8a5 5 0 0010 0M13 8V3H3v5" stroke="#7B5CF0" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg></div><div><div class="pp-feat-name">Comment threads per feature</div><div class="pp-feat-desc">A collapsible comment section under each card lets users clarify their use case. Context-rich comments often reveal higher-priority pain than raw vote counts. Comments persist in localStorage and display timestamps.</div><div class="pp-feat-new">COLLAPSIBLE PER CARD</div></div></div><div class="pp-feat-item"><div class="pp-feat-icon"><svg width="16" height="16" viewBox="0 0 16 16" fill="none"><path d="M4 3h8v8H4z" stroke="#7B5CF0" stroke-width="1.3"/><path d="M2 5h2M2 7h2M2 9h2M12 5h2M12 7h2M12 9h2" stroke="#7B5CF0" stroke-width="1.3" stroke-linecap="round"/></svg></div><div><div class="pp-feat-name">Admin panel + status control</div><div class="pp-feat-desc">One-click admin toggle reveals the full feature list with status dropdowns and power-user toggles. Change any status and a toast fires. When a feature you voted on ships, a confetti celebration plays. The loop closes visibly.</div><div class="pp-feat-new">PASSWORD-FREE DEMO MODE</div></div></div></div><div class="pp-full" style="padding-top:40px;"><div class="pp-section-label"><em>UX DETAILS</em> — THE SMALL THINGS</div><div class="pp-compare"><div class="pp-compare-col"><div class="pp-compare-title" style="color:#7B5CF0;">MICRO-INTERACTIONS</div><div class="pp-compare-item"><span class="icon">→</span>Vote button scale-pops on click (not just color change)</div><div class="pp-compare-item"><span class="icon">→</span>Vote count slides up/out when it increments</div><div class="pp-compare-item"><span class="icon">→</span>Cards stagger-animate in on page load</div><div class="pp-compare-item"><span class="icon">→</span>New submissions slide in, not snap</div><div class="pp-compare-item"><span class="icon">→</span>Confetti fires on vote milestones (every 10 votes)</div><div class="pp-compare-item"><span class="icon">→</span>Toast notifications slide in from right, auto-dismiss</div></div><div class="pp-compare-col"><div class="pp-compare-title" style="color:#7B5CF0;">ACCESSIBILITY & DX</div><div class="pp-compare-item"><span class="icon">→</span>Press N anywhere to jump to submit form</div><div class="pp-compare-item"><span class="icon">→</span>44×44px touch targets on vote buttons</div><div class="pp-compare-item"><span class="icon">→</span>Character counters on title (60) and description (280)</div><div class="pp-compare-item"><span class="icon">→</span>Inline form validation, no browser alert()</div><div class="pp-compare-item"><span class="icon">→</span>Submit loading state (3-dot pulse)</div><div class="pp-compare-item"><span class="icon">→</span>Read more / collapse on long descriptions</div></div></div></div><div class="pp-cta-strip"><h2 class="pp-h2">See every feature<br/><em>live in the board.</em></h2><p>Everything described above is working right now, below this panel.</p><button class="pp-cta-btn" onclick="closePage();window.__scrollTo(document.getElementById('live-board'))">Jump to the live board →</button></div>`,

how: () => `<div class="pp-hero"><div class="pp-eyebrow">THE FULL LOOP</div><h1 class="pp-h1">From scattered chaos<br/>to <em>shipped feature</em> in 5 steps.</h1><p class="pp-lead">Most teams have the chaos. The part that's missing is the infrastructure between "user complains on Twitter" and "engineer picks up ticket." Voxlit is that infrastructure.</p></div><div class="pp-full"><div class="pp-section-label"><em>THE LOOP</em> — STEP BY STEP</div><div class="pp-steps"><div class="pp-step"><div class="pp-step-num">01</div><div><div class="pp-step-title">User submits a request</div><div class="pp-step-desc">A clean form: title (60 chars), description (280 chars), optional name. No login wall. No friction. Before they hit submit, real-time fuzzy matching checks their title against existing requests. If there's a match, they see "Did you mean X?" and can vote on the existing one instead of fragmenting the signal.</div><div class="pp-step-tag">DEDUP FIRES ON KEYSTROKE</div></div></div><div class="pp-step"><div class="pp-step-num">02</div><div><div class="pp-step-title">Request lands on the board</div><div class="pp-step-desc">New features appear at the bottom of the ranked list with 0 votes and Under Review status. They slide in with an animation — never snap. The feature count in the live stats bar updates immediately. The feature is now visible to every user who visits the board.</div><div class="pp-step-tag">INSTANT VISIBILITY</div></div></div><div class="pp-step"><div class="pp-step-num">03</div><div><div class="pp-step-title">Users vote and the board re-ranks</div><div class="pp-step-desc">One click on the "▲ I need this too" button casts a vote. The count animates, the vote button pops with a scale animation, and the board re-sorts immediately. A feature can jump from #8 to #1 in a single session. Voting twice is prevented via localStorage. Unvoting is supported.</div><div class="pp-step-tag">INSTANT RERANK</div></div></div><div class="pp-step"><div class="pp-step-num">04</div><div><div class="pp-step-title">PM reviews and prioritizes</div><div class="pp-step-desc">The admin panel shows the full board with one-click status controls. The Effort/Impact matrix lets the PM drag features into quadrants — Low Effort/High Votes = ship it this sprint. The board goes from "what users want" to "what we should build next" in a single view.</div><div class="pp-step-tag">ADMIN PANEL + MATRIX</div></div></div><div class="pp-step"><div class="pp-step-num">05</div><div><div class="pp-step-title">Feature ships — voters are notified</div><div class="pp-step-desc">When the PM marks a feature as Shipped, a toast notification fires and the Kanban roadmap moves the card to the Shipped column. The loop closes. Users see that their input mattered — and they start submitting more. Teams that close the loop see 3× more submissions in 30 days.</div><div class="pp-step-tag">LOOP CLOSED</div></div></div></div></div><div class="pp-full"><div class="pp-section-label"><em>ANATOMY</em> — WHAT EACH PIECE DOES</div><div class="pp-grid" style="margin:0;"><div class="pp-cell"><div class="pp-cell-num">LIVE STATS BAR</div><div class="pp-cell-title">Always-visible signal</div><div class="pp-cell-desc">The sticky bar shows total votes cast, number of features, and your personal vote count. Updates live with every action. Gives context at a glance before you read a single card.</div></div><div class="pp-cell"><div class="pp-cell-num">SEARCH + FILTER</div><div class="pp-cell-title">Find signal fast</div><div class="pp-cell-desc">Search matches against both title and description. Filter by status. Sort by Top Voted, Newest, or Trending. Three filters in combination = pinpoint precision.</div></div><div class="pp-cell"><div class="pp-cell-num">EFFORT/IMPACT MATRIX</div><div class="pp-cell-title">Votes → sprint decisions</div><div class="pp-cell-desc">Drag any feature card into one of four quadrants. Low effort + high votes in the top-left quadrant = your sprint backlog writes itself. Turns a popularity contest into a prioritization tool.</div></div><div class="pp-cell"><div class="pp-cell-num">PUBLIC ROADMAP KANBAN</div><div class="pp-cell-title">Trust through visibility</div><div class="pp-cell-desc">A three-column Kanban — Planned, In Progress, Shipped — updates automatically when admin changes status. Users see progress without asking. No more "is this on the roadmap?" support tickets.</div></div></div></div><div class="pp-full"><div class="pp-section-label"><em>UNDER THE HOOD</em></div><div class="pp-compare"><div class="pp-compare-col"><div class="pp-compare-title" style="color:#7B5CF0;">ARCHITECTURE</div><div class="pp-compare-item"><span class="icon">→</span>Pure HTML/CSS/JS — no build step</div><div class="pp-compare-item"><span class="icon">→</span>localStorage for full persistence</div><div class="pp-compare-item"><span class="icon">→</span>Levenshtein algorithm for fuzzy match</div><div class="pp-compare-item"><span class="icon">→</span>IntersectionObserver for scroll reveals</div><div class="pp-compare-item"><span class="icon">→</span>requestAnimationFrame for smooth lens</div></div><div class="pp-compare-col"><div class="pp-compare-title" style="color:#7B5CF0;">STORAGE KEYS</div><div class="pp-compare-item"><span class="icon">→</span>fv_votes — counts + user voted IDs</div><div class="pp-compare-item"><span class="icon">→</span>fv_features — submitted feature objects</div><div class="pp-compare-item"><span class="icon">→</span>fv_comments — comment threads per feature</div><div class="pp-compare-item"><span class="icon">→</span>fv_matrix — quadrant placements</div><div class="pp-compare-item"><span class="icon">→</span>fv_power — power user feature flags</div></div></div></div><div class="pp-cta-strip"><h2 class="pp-h2">The whole loop is<br/><em>live right now.</em></h2><p>Every step described above — submit, vote, rank, admin review, ship — works in the board below.</p><button class="pp-cta-btn" onclick="closePage();window.__scrollTo(document.getElementById('live-board'))">Try the live board →</button></div>`
};

const PAGE_TITLES = { product:'PRODUCT', features:'FEATURES', how:'HOW IT WORKS' };

function openPage(key) {
  const panel = document.getElementById('page-panel');
  const backdrop = document.getElementById('page-backdrop');
  const body = document.getElementById('panel-body');
  const titleBar = document.getElementById('panel-title-bar');
  body.innerHTML = PAGES[key]();
  titleBar.textContent = PAGE_TITLES[key];
  backdrop.style.pointerEvents = 'all';
  backdrop.style.opacity = '1';
  panel.style.transform = 'translateX(0)';
  document.body.style.overflow = 'hidden';
  document.querySelectorAll('.nav-link-btn').forEach(a => {
    a.style.color = a.dataset.page === key ? '#F2F2F0' : '';
  });
  panel.scrollTop = 0;
}

function closePage() {
  const panel = document.getElementById('page-panel');
  const backdrop = document.getElementById('page-backdrop');
  panel.style.transform = 'translateX(100%)';
  backdrop.style.opacity = '0';
  backdrop.style.pointerEvents = 'none';
  document.body.style.overflow = '';
  document.querySelectorAll('.nav-link-btn').forEach(a => a.style.color = '');
}

document.addEventListener('keydown', e => { if (e.key === 'Escape') closePage(); });